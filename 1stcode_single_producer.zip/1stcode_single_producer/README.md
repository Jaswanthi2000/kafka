# Kafka Producer README

## Overview

This is a simple Kafka producer application written in Java using the Spring Kafka library. The producer sends 10,000 messages to a Kafka topic named `pc_topic3`.

## Setup

1. **Kafka Server:**
   - Ensure that your Kafka server is running on `localhost:9092`. Update the `bootstrap-servers` property in the `application.yml` file if your Kafka server is running on a different host or port.

## How to Run

1. Build the project using your favorite Java build tool (Maven, Gradle, etc.).
2. Run the `KafkaProducerExample` class.

## Example Output

Upon running the producer, you should see messages like:

```plaintext
Produced message: Message 1
Produced message: Message 2
...
