package com.example.demo_createTopic;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.NewTopic;
import com.example.demo.HardCode.ProducerConstants;
import com.example.demo.HardCode.ProducerMessage;
import java.util.Properties;
import java.util.Collections;

public class CreateKafkaTopic {

	public static void main(String[] args) {

		// Set up properties for the AdminClient
		Properties properties = new Properties();
		properties.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");

		try (AdminClient adminClient = AdminClient.create(properties)) {

			// Define topic properties
			String topicName = ProducerConstants.PC_TOPIC3;
			int numPartitions = 3;
			NewTopic newTopic = new NewTopic(topicName, numPartitions, (short) 1);

			// Create the Kafka topic
			adminClient.createTopics(Collections.singletonList(newTopic)).all().get();

			// Print success message
			System.out.println(ProducerMessage.TOPIC_CREATED_SUCCESSFULLY);
		}

		catch (Exception e) {
			// Handle exceptions
			e.printStackTrace();
		}
	}
}
