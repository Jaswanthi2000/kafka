package com.example.demo.service;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import com.example.demo.HardCode.ProducerConstants;
import com.example.demo.HardCode.ProducerMessage;
import java.util.Properties;

public class KafkaProducerExample {

	public static void main(String[] args) {

		// Set up properties for the Kafka producer
		Properties properties = new Properties();
		properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.StringSerializer");
		properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
				"org.apache.kafka.common.serialization.StringSerializer");

		try (Producer<String, String> producer = new KafkaProducer<>(properties)) {

			// Define the Kafka topic
			String topicName = ProducerConstants.PC_TOPIC3;

			// Produce 10,000 messages to the Kafka topic
			for (int i = 0; i < 10000; i++) {
				String message = ProducerMessage.MESSAGE + i;
				ProducerRecord<String, String> record = new ProducerRecord<>(topicName, message);

				// Send the message to the Kafka topic
				producer.send(record);
				System.out.println(ProducerMessage.PRODUCED_MESSAGE + message);
			}

		} catch (Exception e) {
			// Handle exceptions
			e.printStackTrace();
		}
	}
}
