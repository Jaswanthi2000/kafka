package com.example.demo.HardCode;

public class ProducerMessage {

	public static final String TOPIC_CREATED_SUCCESSFULLY = "Topic created successfully";
	public static final String MESSAGE = "Message ";
	public static final String PRODUCED_MESSAGE = "Produced message: ";

}
