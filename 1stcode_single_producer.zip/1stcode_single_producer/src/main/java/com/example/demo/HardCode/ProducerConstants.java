package com.example.demo.HardCode;

public class ProducerConstants {

	public static final String PC_TOPIC3 = "pc_topic3";

}
