package com.example.demo.HardCode;

public class ConsumerMessages {
	
	public static final String RECEIVED_MESSAGE = "Received message: ";

}
