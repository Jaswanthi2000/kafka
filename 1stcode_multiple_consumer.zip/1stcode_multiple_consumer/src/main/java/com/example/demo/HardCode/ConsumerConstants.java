package com.example.demo.HardCode;

public class ConsumerConstants {

	public static final String PC_TOPIC3 = "pc_topic3";
	public static final String P_ID = "p_id";

}
