package com.example.demo.service;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.example.demo.HardCode.ConsumerConstants;
import com.example.demo.HardCode.ConsumerMessages;

@Service
public class KafkaConsumerExample {

	@KafkaListener(topics = ConsumerConstants.PC_TOPIC3, groupId = ConsumerConstants.P_ID)

	public void listen(String message) {

		System.out.println(ConsumerMessages.RECEIVED_MESSAGE + message);

	}
}
