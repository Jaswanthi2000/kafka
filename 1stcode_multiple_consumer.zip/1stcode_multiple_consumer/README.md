## Kafka Consumer README

### Overview

This is a simple Kafka consumer application written in Java using the Spring Kafka library. The consumer listens to a Kafka topic named `pc_topic3` and prints received messages to the console.

### Setup

1. **Kafka Server:**
   - Ensure that your Kafka server is running on `localhost:9092`. Update the `bootstrap-servers` property in the `application.yml` file if your Kafka server is running on a different host or port.

2. **Consumer Configuration:**
   - The consumer is configured with the group ID `p_id`. Make sure that the specified group ID aligns with your Kafka cluster configuration.

### How to Run

1. Build the project using your favorite Java build tool (Maven, Gradle, etc.).
2. Run the `KafkaConsumerExample` class.

### Example Output

Upon running the consumer, you should see messages like:

```plaintext
Received message: Message 1
Received message: Message 2
...